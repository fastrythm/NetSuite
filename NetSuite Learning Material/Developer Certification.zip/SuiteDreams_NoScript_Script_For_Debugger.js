/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the functionality and capabilities of SuiteScript Debugger
 * 
 * Approaches to debugging:
 *     1 - Debug Script in New Script window
 *     2 - Debug Existing script
 *     3 - Debug Script, but copy/paste portions of an existing script into the New Script window
 * 
 * Debugging tips beyond the basics:
 *     - Learn about server-side SuiteScript/JavaScript by testing script in the New Script window
 *     - If you are working on a complex script and not quite ready to deploy it, you can copy
 *       portions of it into the New Script window. Just be sure to modify any code that relies on
 *       current context (e.g. record id from the current record in user event script).
 *     - If you are working on building dynamic searches such as with search filters dynamically
 *       constructed in code, it can sometimes be a bit difficult to ascertain the filter IDs when
 *       working with standard records such as transactions. A good approach is to first create a
 *       saved search with the desired filters, then extract the filters from an nlobjSearch object.
 *       You'll be able to see exactly what you need to build dynamically.
 *     - Recognize that data you see in the debugger is considered private and may not be officially
 *       supported. For example, always verify field IDs of nlobjRecord objects against the SuiteScript
 *       Records Browser.
 *     - It can be helpful to run your entire script in the debugger and then check the result of Local
 *       Variables. However, all Local Variables are lost if the script truly runs to completion. Add
 *       a dummy statement to the end of your script, setting a breakpoint on it. This allows you to run
 *       every line of the "real" code and then still see the values of Local Variables.
 *     - When running script in the debugger, all nlapiLogExecution statements log to the Execution Log
 *       subtab in the debugger instead of on the script/script deployment.
 */

/*
 * The code below is sample code showing how you can extract filters out of a search for the eventual purpose
 * of building the search dynamically in your code.
 */

// get nlobjSearch of saved search
var search =
	nlapiLoadSearch('transaction', 'customsearch_sdr_get_orders_script_debug');

// get filter expression, which is object containing filter ids, operators, values,
// and logical operators (AND/OR)
var filterExpression = search.getFilterExpression();

var expression = '', expressionComponent;

// parse out the filter expression, generating an expression string that might look similar
// as follows: type---anyof---SalesOrd---, AND ,mainline---is---T---, AND ,amount---greaterthan---20000.0
//
for (var i=0; i < filterExpression.length; i++){
	expressionComponent = filterExpression[i];
	
	// Filter expression contains strings and embedded arrays. The strings contain logical operators
	// such as AND / OR, and the embedded arrays contain the filter id, operator, and value(s)
	if (typeof expressionComponent != 'string'){
		for (var j=0; j < expressionComponent.length; j++){
			if (expressionComponent[j]){
				expression += expressionComponent[j] + '---';
			}
		}
	} else {
		expression += ', ' + expressionComponent + ' ,'
	}
}

nlapiLogExecution('DEBUG', 'filter expression' + expression);


// get array of nlobjSearchFilter objects
var searchFilters = search.getFilters();

var filterName, filterOperator;

// parse out the filter id and operator components of each nlobjSearchFilter and log them
for (var i=0; i < searchFilters.length; i++){
	
	filterName = searchFilters[i].getName();
	filterOperator = searchFilters[i].getOperator();

	nlapiLogExecution('DEBUG', 'filter ' + (i+1), 'name: ' + filterName + 
			          ', operator: ' + filterOperator);
}

var x = 0; // dummy statement to allow break in debugger so you can still see local variables

/*
 * The code below is sample code showing how you can modify portions of an existing script
 * that contains UI context (i.e. user event script), and then execute directly in the 
 * debugger's New Script window. 
 * 
 * This sample uses one of the valid code options from SuiteDreams_UE_DescribeBusProcess.js
 */

// nlapiGetNewRecord only has context within user event script	
//var recOpp = nlapiGetNewRecord();

// Temporarily hardcode specific record to load. This is in place of nlapiGetNewRecord.
var recOpp = nlapiLoadRecord('opportunity', 802);

var projectedTotal = parseFloat(recOpp.getFieldValue('projectedtotal'));
var estimatedBudget = parseFloat(recOpp.getFieldValue('estimatedbudget'));

if (estimatedBudget && estimatedBudget < projectedTotal) {
	
	var potentialShortfall = projectedTotal - estimatedBudget;
	
	var recTask = nlapiCreateRecord('task');
	recTask.setFieldValue('title', 'potential shortfall');
	
	// Any use of nlapiGetFieldValue in user event script must be replaced with direct
	// access on record object.	
	//if (nlapiGetFieldValue('salesrep')){
    if (recOpp.getFieldValue('salesrep')) {
		recTask.setFieldValue('assigned', recOpp.getFieldValue('salesrep'));		
	}

	recTask.setFieldValue('message', 'There is potential shortfall of ' +
			              potentialShortfall + ' with the related opportunity');
	
	recTask.setFieldValue('company', recOpp.getFieldValue('entity'));

	// Any use of nlapiGetFieldValue in user event script must be replaced with direct
	// access on record object.	
	//recTask.setFieldValue('transaction', nlapiGetRecordId());
	recTask.setFieldValue('transaction', recOpp.getId());

	nlapiSubmitRecord(recTask);
}
