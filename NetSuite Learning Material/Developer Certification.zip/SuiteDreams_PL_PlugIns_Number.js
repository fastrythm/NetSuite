/**
 * Developer Certification
 * 
 * Objective:
 *     Recognize the purpose of Plug-Ins in SuiteScript
 * 
 * This is an html portlet showing use of a custom Plug-In.
 * 
 * Plug-In notes:
 *     - The Custom Plug-in Type can have its DEPLOYMENT MODEL set to Allow Single or Allow Multiple.
 *     - Behavior when set to Allow Multiple:
 *           - All implementations (default and alternate) can be executed. To execute an alternate
 *             implementation, you pass in the script id as a parameter when instantiating the class,
 *             e.g. new NumberManipulation('customscript_sdr_plugin_nbr_man_alt1')
 *     - Behavior when set to Allow Single:
 *           - When the Default is the active implementation, behavior is the same as Allow Multiple
 *           - When an alternate implementation is chosen as the active implementation, the parameter
 *             passed into the instantiation of the class is ignored.
 *             e.g. new NumberManipulation() will use the alternate implementation that has been
 *                  actively deployed
 */

function showNumbers(portlet, column)
{

	var html;
	
	// Use default implementation to set precision
	var numberManipulationDflt = new NumberManipulation();
	
	var formattedNumberDflt =
		numberManipulationDflt.setPrecision(86.234, 8);

	html =
	    '<div style="color:red;font-size:24px">' + 
	    'Formatted number (default implementation): ' + 
		formattedNumberDflt + '</div>';	
	
	// Use default implementation to generate random number
	var randomNumberDflt = numberManipulationDflt.generateRandomNumber(100,3);

	html = html +
	    '<div style="color:red;font-size:24px">' + 
		'Random number (default implementation): ' + 
		randomNumberDflt + '</div>';	
	
	// Use alternate implementation to set precision
	var numberManipulationAlt1 = 
		new NumberManipulation('customscript_sdr_plugin_nbr_man_alt1');

	var formattedNumberAlt1 = numberManipulationAlt1.setPrecision(86.234, 8);

	html = html +
	    '<div style="color:red;font-size:24px">' + 
		'Formatted number (alternate implementation): ' + 
		formattedNumberAlt1 + '</div>';	
	
	// Use alternate implementation to generate random number	
	var randomNumberAlt1 = numberManipulationAlt1.generateRandomNumber(100,3);

	html = html +
	    '<div style="color:red;font-size:24px">' + 
		'Random number (alternate implementation): ' + 
		randomNumberAlt1 + '</div>';	
	
	portlet.setHtml(html);
	portlet.setTitle('Number Info');
}
