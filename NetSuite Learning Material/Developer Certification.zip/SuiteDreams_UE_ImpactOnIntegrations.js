/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the impact of scripts and workflows on integrations.
 * 
 * SuiteTalk integrations can execute user events.
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord task
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type){
	var context = nlapiGetContext();
	var executionContext = context.getExecutionContext();
	
	if (executionContext == 'webservices'){
		nlapiLogExecution('DEBUG', 'executing based off of a SuiteTalk operation');
	} else {
		nlapiLogExecution('DEBUG', 'executing from someplace else');
	}	
}
