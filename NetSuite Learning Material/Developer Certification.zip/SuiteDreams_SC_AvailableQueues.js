/**
 * Developer Certification
 * 
 * Objective:
 *     Identify how to dynamically scale a scheduled script utilization to match
 *     available queues in the account
 * 
 * This is a scheduled script that gets called to operate upon a segment of support cases.
 */
/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type, queue) {

	var context = nlapiGetContext();
	
	// get deployment id and format into string that is embedded into log statements
	var deployId = 'deployment id: ' + context.getDeploymentId() + ', ';
	
	nlapiLogExecution('DEBUG', deployId + 'queue number', queue);
	
	// grab script parameters from suitelet script that is calling this
	var startCaseId = context.getSetting('SCRIPT', 'custscript_sdr_start_case_id');
	var endCaseId = context.getSetting('SCRIPT', 'custscript_sdr_end_case_id');

	// Formulate filters for search
	// Note: between operator is inclusive of starting and ending values
	var filters = [];
	filters[0] = new nlobjSearchFilter('internalidnumber', null, 'between', 
			                           startCaseId, endCaseId);
	
	var searchResults = 
		nlapiSearchRecord('supportcase', 'customsearch_sdr_get_support_cases', filters);
	
	// Get first and last records in search results
	if (searchResults){
		var firstRecord = searchResults[0];
		var lastRecord = searchResults[searchResults.length-1];
	}
	
	// log the requested starting and ending support case internal IDs	
	nlapiLogExecution('DEBUG', deployId + 'starting case id', startCaseId);
	nlapiLogExecution('DEBUG', deployId + 'ending case id', endCaseId);
	
	// log the number of search results, including case numbers for first and last result
	nlapiLogExecution('DEBUG', deployId + 'number of cases', searchResults.length);
	nlapiLogExecution('DEBUG', deployId + 'first record case number', firstRecord.getValue('casenumber'));
	nlapiLogExecution('DEBUG', deployId + 'last record case number', lastRecord.getValue('casenumber'));	
}
