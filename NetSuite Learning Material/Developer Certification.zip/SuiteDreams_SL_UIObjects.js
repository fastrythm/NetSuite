/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the capabilities of UI objects
 * 
 * UI objects are very powerful. This shows how you can create a custom
 * nlobjForm based user interfaces with fields, field groups, subtabs,
 * and sublists.
 * 
 * There is much more. You can create List and Assistant interfaces too.
 * Portions of portlet objects have similarities. Before Load user
 * event scripts accept an nlobjForm parameter, so there is some ability
 * to add to and manipulate forms in UE scripts.
 * See Help Center for details.
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){
	
	// GET request to generate UI
	if (request.getMethod() == 'GET'){
				
		var form = nlapiCreateForm
		('nlobjForm With Standard Content', false);
		
		// add field group
		var fieldGroup1 = form.addFieldGroup('fieldgroup1', 'Field Group 1');
		
		// add fields, associating with field group
		var field1 = form.addField('field1', 'text', 'Field 1', null, 'fieldgroup1');
		
		var field2 = form.addField('field2', 'currency', 'Field 2', null, 'fieldgroup1');
		field2.setDefaultValue(777444.88);
		
		var field3 = form.addField('field3', 'richtext', 'Field 3', null, 'fieldgroup1');
		field3.setMandatory(true);
		field3.setDisplaySize(20, 4);
		
		var field4 = form.addField('field4', 'text', 'Field 4', null, 'fieldgroup1');
		field4.setDisplayType('disabled');
		
		var field5 = form.addField('field5', 'text', 'Field 5', null, 'fieldgroup1');
		field5.setHelpText('This is field5. Enter something nice.');

		// add a subtab
		var tab = form.addTab('subtab1', 'Subtab 1');

		// add fields to subtab
		var field6 = form.addField('field6', 'text', 'Subtab Field 1', null, 'subtab1');
		var field7 = form.addField('field7', 'text', 'Subtab Field 2', null, 'subtab1');
		
		// add another subtab
		var tab = form.addTab('subtab2', 'Subtab 2');
		
		// add field to the other subtab
		var field8 = form.addField('field8', 'text', 'Subtab Field 3', null, 'subtab2');

		// add sublist to 2nd subtab
		var sublist1 = form.addSubList('sublist1', 'inlineeditor', 'Sublist 1', 'subtab2');
		sublist1.addField('subfield1', 'select', 'Sublist Field 1', 'item');
		sublist1.addField('subfield2', 'text', 'Sublist Field 2');
		sublist1.addField('subfield3', 'integer', 'Sublist Field 3');
		
        var message = form.addField('message', 'help', 'Suitelet submitted!!!');
       
        if (request.getParameter('postcomplete') == 'T'){
        	message.setDisplayType('inline');
        } else {
        	message.setDisplayType('hidden');        	
        }
        
        message.setLayoutType('outsideabove', 'startrow');
		
		
		// add a submit button
		form.addSubmitButton('Some Button');
		
		// write the response
		response.writePage(form);		
	} else {
		// POST - button clicked
		
		// get request params and log, but could also access NetSuite DB
		var field2 = request.getParameter('field2');
		nlapiLogExecution('DEBUG', field2);

		var field3 = request.getParameter('field3');
		nlapiLogExecution('DEBUG', field3);
		
		// redirecting back to self
		var context = nlapiGetContext();
		var scriptId = context.getScriptId();
		var deploymentId = context.getDeploymentId();
		response.sendRedirect('SUITELET', scriptId, deploymentId,
				              null, {postcomplete:'T'});
	}
}
