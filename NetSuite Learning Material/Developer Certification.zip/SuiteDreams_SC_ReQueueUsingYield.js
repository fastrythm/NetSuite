/**
 * Developer Certification
 * 
 * Objective:
 *     Given a scenario, identify the proper pattern to invoke a scheduled script to support
 *     a long running process
 * 
 * This is a scheduled script, showing how it can re-queue itself to continue processing the
 * result set. The re-queue is achieved using nlapiYieldScript. This automatically saves what
 * is in memory. Processing is resumed in a new execution of the scheduled script with the
 * response to nlapiYieldScript. Scheduled scripts may need to be re-queued when governance
 * limits for the scheduled script is about to be exceeded.
 */

function scheduledScript(type, queue)
{
	var context = nlapiGetContext();
	nlapiLogExecution('DEBUG', 'remaining usage-START', context.getRemainingUsage());
		
	var searchColumns = [];
	searchColumns[0] = new nlobjSearchColumn('title');
     
    var searchResults = nlapiSearchRecord('supportcase', null, null, searchColumns);
     
    for (var i=0; i < searchResults.length; i++) {
		var searchResult = searchResults[i];
				
		// A yield will take place every 20 records. In a real-life use case, you would normally
		// go until you are about to exceed governance limits
		if (i % 20 == 0 && i != 0) 
		{ 
			nlapiLogExecution('DEBUG', 'BEFORE YIELD-remaining usage', context.getRemainingUsage());
							  
			var state = nlapiYieldScript();

			nlapiLogExecution('DEBUG', 'AFTER YIELD-remaining usage', context.getRemainingUsage());

			for (var prop in state) 
			{
				nlapiLogExecution('DEBUG', prop, state[prop]);
			}			
		}

		var recCase = nlapiLoadRecord(searchResult.getRecordType(), searchResult.getId());
		
		nlapiLogExecution('DEBUG', 'case number', recCase.getFieldValue('casenumber'));
    }
}
