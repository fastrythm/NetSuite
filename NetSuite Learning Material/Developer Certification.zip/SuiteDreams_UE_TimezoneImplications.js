/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the time zone implications of various ways of setting date and/or
 *     time values and the ways in which these values are interpreted in SuiteScript
 * 
 * Tips for User Event Scripts and Time Zone
 * ---------------------------------------------------------------------------------
 * - "new Date()" on client-side returns JavaScript date in time zone based on
 *   browser settings
 * - "new Date()" on server returns JavaScript date with time according to Pacific
 *   time zone. This is the same whether the account is located in the west coast or 
 *   east coast data center. As of the time of this writing, your training accounts are
 *   in a data center on the east coast of the United States.
 * - When time zone is not explicitly entered, datetime values are returned using
 *   the TIME ZONE user preference at Home > Set Preferences.
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord invoice
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function userEventBeforeLoad(type, form, request){
	
	// Date such as DATE (trandate) on new record is set from client side, so value is empty
	// during initial loading of a new invoice form
	var rec = nlapiGetNewRecord();
	var tranDate =  rec.getFieldValue('trandate');
	
	// trandate not existing at Before Load when new form is requested, so this section
	//   only executes upon re-load of the record after it is created or updated
	// When new form is requested, trandate on the form defaults to date based on TIME ZONE  
	//   setting of user at Home > Set Preferences. 
	if (tranDate){
		
		// trandate only has date component, which reflects date as entered in the UI
		nlapiLogExecution('DEBUG', 'trandate-beforeLoad-source', tranDate);
		
		// When form originally submitted, the DATE (trandate) had no time component. It is defaulted
		// to midnight Pacific time when stored on the server.
		//
		// Supplying the DATE to nlapiStringToDate generates a JavaScript date at midnight (0000)
		// Pacific time. toUTCString converts to GMT time, and will be reflected as 0800 GMT.
		// Note the GMT offset will differ depending on time of year based upon moving to/from daylight
		// savings time. There may be 7 or 8 hours between Pacific time and GMT time.
		//
		// Note: there may be some insconsistencies when running code via script debugger
		//
		// nlapiStringToDate accepts date strings in the format of preferred DATE FORMAT only, but
		// since dates returned are always tied to this format when using record APIs, things should
		// be fine unless supplying custom date strings.
		//
		var tranDate2 = nlapiStringToDate(tranDate);
		var utcTranDate = tranDate2.toUTCString(); 
				
		nlapiLogExecution('DEBUG', 'trandate-beforeLoad-UTC', utcTranDate);		
	}
		
	// Use a custom record type with a datetime field as a general purpose utility for converting
	// from server timezone to user or company specified timezone. The custom record type should
	// have at least a single date time field. No data records are needed.  
	var recDateTimeConverter = nlapiCreateRecord('customrecord_sdr_datetime_converter');
	
	// Field "custrecord_sdr_user_datetime" uses Current Date/Time as a DYNAMIC DEFAULT 
	// (see Validation & Defaulting subtab of field definition). 
	// DYNAMIC DEFAULT is set to time based on user preference in most scripts
	// DYNAMIC DEFAULT is set to time based on company preference in scheduled scripts
	var userDateTime = recDateTimeConverter.getFieldValue('custrecord_sdr_user_datetime');
	nlapiLogExecution('DEBUG', 'user datetime from datetime field using dynamic default', userDateTime);

	var serverDate = new Date();
	var serverDateTime = nlapiDateToString(serverDate, 'datetimetz');
	nlapiLogExecution('DEBUG', 'current JS date on server - always Pacific time', serverDateTime);		
	
	// We specify the timezone as America/Los_Angeles Olson value. A new JS Date (i.e. using new Date())
	// is always returned in Pacific time, so let's have it associated with this timezone.
	recDateTimeConverter.setDateTimeValue('custrecord_sdr_server_datetime', serverDateTime,
			                              'America/Los_Angeles');
	
	// Returns in timezone of user preference in most scripts
	// Returns in timezone of company preference in scheduled scripts
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with no timezone specified', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime'));

	// getFieldValue returns the same as getDateTimeValue when 2nd parameter not entered
	nlapiLogExecution('DEBUG', 'getFieldValue - returned with no timezone specified', 
			recDateTimeConverter.getFieldValue('custrecord_sdr_server_datetime'));

	// Converts the time (currently stored as Pacific) to Mountain
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with explicit conversion to America/Denver time', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime','America/Denver'));
	
	// Returns the TIME ZONE user preference setting in most scripts
	// Returns the TIME ZONE company preference setting in scheduled scripts 
	// The time zone value is returned as an Olson value, e.g. "Asia/Manila"
	var userTimeZone = nlapiLoadConfiguration('userpreferences').getFieldValue('timezone');
	nlapiLogExecution('DEBUG', 'user time zone', userTimeZone);	
	
	
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with explcit conversion to user timezone', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime', userTimeZone));	
	
	// Return the the TIME ZONE company preference setting. The time zone value is returned as an
	// Olson value, e.g. "Asia/Manila"
	var companyTimeZone = nlapiLoadConfiguration('companyinformation').getFieldValue('timezone');
	nlapiLogExecution('DEBUG', 'company time zone', companyTimeZone);	
	
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with explcit conversion to company timezone', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime', companyTimeZone));		        	
}
