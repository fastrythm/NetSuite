/**
 * Developer Certification
 * 
 * Objective:
 *     Identify implications of managing a large volume of search results    
 * 
 * This search implements the same pattern as in file
 * SuiteDreams_NoScript_LargeVolumeSearchResults.js, but is using nlobjSearch.
 * 
 * Note: nlobjSearch.runSearch() returns an nlobjSearchResultSet.
 *       nlobjSearchResultSet is not saved when executing nlapiYieldScript()
 *       in a scheduled script. To use nlobjSearch with yield,
 *       you'll need to null out any nlobjSearchResultSet objects, otherwise
 *       you will get an error at the time a yield is executed.
 */

var columns = [];
columns[0] = new nlobjSearchColumn('tranid'); // transaction number
columns[1] = new nlobjSearchColumn('amount');
columns[2] = new nlobjSearchColumn('internalid').setSort();

var filters = [];
filters[0] = new nlobjSearchFilter('type', null, 'anyof', 'CustPymt');
filters[1] = new nlobjSearchFilter('mainline', null, 'is', 'T');

var recsProcessed = 0; // total number of search results processed

// grab first set of search results
var search = nlapiCreateSearch('transaction', filters, columns);
var resultSet = search.runSearch();
var startIndex = 0;
var searchResults = resultSet.getResults(startIndex, startIndex + 1000);

while (searchResults.length == 1000){
	
	recsProcessed = recsProcessed + searchResults.length;
	nlapiLogExecution('DEBUG', 'records processed: ' + recsProcessed);

	var lastInternalId = searchResults[999].getValue('internalid');
										   
	// get another set of search results
	startIndex += 1000;
	var searchResults = resultSet.getResults(startIndex, startIndex + 1000);
}

recsProcessed = recsProcessed + searchResults.length;
nlapiLogExecution('DEBUG', 'records processed: ' + recsProcessed);

var x=0;

