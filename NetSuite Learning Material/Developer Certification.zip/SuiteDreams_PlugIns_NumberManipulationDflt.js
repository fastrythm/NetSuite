/**
 * Developer Certification
 * 
 * Objective:
 *     Recognize the purpose of Plug-Ins in SuiteScript
 * 
 * The purpose of this example plug-in is to provide default
 * methods of generating random numbers and calculating precision.
 * The idea is that solution implementers can override with
 * alternative implementations.
 * 
 * This is the default implementation. It defines two methods:
 * generateRandomNumber and setPrecision. The signature of
 * each method returns a number. 
 * 
 */


/*
 * Generate random number, establishing a maximum. One is added, so number will 
 * never be less than one. Math.random generates random number between 0 and 1.
 */ 
function generateRandomNumber(maxNbr, decimalPlaces)
{
	// decimalPlaces ignored in the default implementation
	
	var randomNumber = 
		(Math.random() * maxNbr) + 1;
	return Math.floor(randomNumber);
}

/*
 * Pass in a number and pad to specified length
 */
function setPrecision(number, length)
{
	return number.toPrecision(length);
}
