/**
 * Developer Certification
 * 
 * Objective:
 *     Select the SuiteScript Code Snippet that Implements a Described Business Process
 * 
 * Business Process: Upon creating an Opportunity record from the user interface by a 
 *                   NetSuite user logged in as an Administrator, create a related
 *                   Task record for the SALES REP if the customer's ESTIMATED BUDGET
 *                   is less than the PROJECTED TOTAL.
 *                   
 * There are 6 user event script functions identified below. Assume each has the same deployment.
 * They are deployed to the Opportunity record and assigned to the After Submit event.
 * 
 * Which 2 of the 6 script functions are valid. Why are the other 4 functions not valid?
 * 
 * See SuiteDreams_UE_DescribeBusProcessAnswers.txt for answers.
 * 
 */

/*
 * Option 1
 */
function userEventAfterSubmit_option1(type){	
	
	var recOpp = nlapiGetNewRecord();

	var projectedTotal = parseFloat(recOpp.getFieldValue('projectedtotal'));
	var estimatedBudget = parseFloat(recOpp.getFieldValue('estimatedbudget'));
	
	if (estimatedBudget && estimatedBudget < projectedTotal) {
		
		var potentialShortfall = projectedTotal - estimatedBudget;
		
		var recTask = new nlobjRecord('task');
		recTask.setFieldValue('title', 'potential shortfall');
				
		if (nlapiGetFieldValue('salesrep')){
			recTask.setFieldValue('assigned', recOpp.getFieldValue('salesrep'));		
		}
	
		recTask.setFieldValue('message', 'There is potential shortfall of ' +
				              potentialShortfall + ' with the related opportunity');
		
		recTask.setFieldValue('company', recOpp.getFieldValue('entity'));
		recTask.setFieldValue('transaction', nlapiGetRecordId());
		
		nlapiSubmitRecord(recTask);
	}	
}

/*
 * Option 2
 */
function userEventAfterSubmit_option2(type){	
	
	var projectedTotal = parseFloat(nlapiGetFieldValue('projectedtotal'));
	var estimatedBudget = parseFloat(nlapiGetFieldValue('estimatedbudget'));
	
	if (estimatedBudget && estimatedBudget < projectedTotal) {
		
		var potentialShortfall = projectedTotal - estimatedBudget;
		
		var recTask = nlapiCreateRecord('task');
		recTask.setFieldValue('title', 'potential shortfall');
				
		if (nlapiGetFieldValue('salesrep')){
			recTask.setFieldValue('assigned', nlapiGetFieldValue('salesrep'));		
		}
	
		recTask.setFieldValue('message', 'There is potential shortfall of ' +
				              potentialShortfall + ' with the related opportunity');
		
		recTask.setFieldValue('company', nlapiGetFieldValue('entity'));
		recTask.setFieldValue('transaction', nlapiGetRecordId());
		
		nlapiSubmitRecord(recTask);
	}	
}

/*
 * Option 3
 */
function userEventAfterSubmit_option3(type){	
	
	var projectedTotal = parseFloat(nlapiGetFieldValue('projectedtotal'));
	var estimatedBudget = parseFloat(nlapiGetFieldValue('estimatedbudget'));
	
	if (estimatedBudget && estimatedBudget < projectedTotal) {
		
		var potentialShortfall = projectedTotal - estimatedBudget;
		
		var recTask = new nlobjRecord('task');
		recTask.setFieldText('title', 'potential shortfall');
				
		if (nlapiGetFieldValue('salesrep')){
			recTask.setFieldValue('assigned', nlapiGetFieldValue('salesrep'));		
		}
	
		recTask.setFieldText('message', 'There is potential shortfall of ' +
				              potentialShortfall + ' with the related opportunity');
		
		recTask.setFieldValue('company', nlapiGetFieldValue('entity'));
		recTask.setFieldValue('transaction', nlapiGetRecordId());
		
		nlapiSubmitRecord(recTask);
	}	
}


/*
 * Option 4
 */
function userEventAfterSubmit_option4(type){	
	
	var recOpp = nlapiGetNewRecord();

	var projectedTotal = parseFloat(recOpp.getFieldValue('projectedtotal'));
	var estimatedBudget = parseFloat(recOpp.getFieldValue('estimatedbudget'));
	
	if (estimatedBudget && estimatedBudget < projectedTotal) {
		
		var potentialShortfall = projectedTotal - estimatedBudget;
		
		var recTask = nlapiCreateRecord('task');
		recTask.setFieldText('title', 'potential shortfall');
				
		if (nlapiGetFieldValue('salesrep')){
			recTask.setFieldValue('assigned', recOpp.getFieldValue('salesrep'));		
		}
	
		recTask.setFieldText('message', 'There is potential shortfall of ' +
				              potentialShortfall + ' with the related opportunity');
		
		recTask.setFieldValue('company', recOpp.getFieldValue('entity'));
		recTask.setFieldValue('transaction', nlapiGetRecordId());
		
		nlapiSubmitRecord(recTask);
	}	
}

/*
 * Option 5
 */
function userEventAfterSubmit_option5(type){	
	
	var recOpp = nlapiGetNewRecord();

	var projectedTotal = parseFloat(recOpp.getFieldValue('projectedtotal'));
	var estimatedBudget = parseFloat(recOpp.getFieldValue('estimatedbudget'));
	
	if (estimatedBudget && estimatedBudget < projectedTotal) {
		
		var potentialShortfall = projectedTotal - estimatedBudget;
		
		var recTask = nlapiCreateRecord('task');
		recTask.setFieldValue('title', 'potential shortfall');
				
		if (nlapiGetFieldValue('salesrep')){
			recTask.setFieldValue('assigned', recOpp.getFieldValue('salesrep'));		
		}
	
		recTask.setFieldValue('message', 'There is potential shortfall of ' +
				              potentialShortfall + ' with the related opportunity');
		
		recTask.setFieldValue('company', recOpp.getFieldValue('entity'));
		recTask.setFieldValue('transaction', nlapiGetRecordId());
		
		nlapiSubmitRecord(recTask);
	}	
}

/*
 * Option 6
 */
function userEventAfterSubmit_option6(type){	
	
	var projectedTotal = parseFloat(nlapiGetFieldValue('projectedtotal'));
	var estimatedBudget = parseFloat(nlapiGetFieldValue('estimatedbudget'));
	
	if (estimatedBudget && estimatedBudget < projectedTotal) {
		
		var potentialShortfall = projectedTotal - estimatedBudget;
		
		var recTask = nlapiCreateRecord('task');
		recTask.setFieldText('title', 'potential shortfall');
				
		if (nlapiGetFieldValue('salesrep')){
			recTask.setFieldValue('assigned', nlapiGetFieldValue('salesrep'));		
		}
	
		recTask.setFieldText('message', 'There is potential shortfall of ' +
				              potentialShortfall + ' with the related opportunity');
		
		recTask.setFieldValue('company', nlapiGetFieldValue('entity'));
		recTask.setFieldValue('transaction', nlapiGetRecordId());
		
		nlapiSubmitRecord(recTask);
	}	
}

