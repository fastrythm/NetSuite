/**
 * Developer Certification
 * 
 * Objective:
 *     Determine the impact of form customization on records
 * 
 * This script is non-specific to any script type. It can be executed in the script debugger.
 * The script updates an employee record using a specific form. You get to see how changes
 * to display type and mandatory/optional designation impact attempts to update the record.
 */

// Load an employee record for update using a specific form.
// The form specified is then used to process the update during
// execution of nlapiSubmitRecord. The preferred form is used if
// customform not specified.
var recEmployee = nlapiLoadRecord('employee', 15, {customform: 28});
// form 28 = Employee Form Customization Impact

// Form used when testing this script has the following adjustments
// from the Standard Employee Form:
//     OFFICE PHONE (SHOW unchecked)
//     MOBILE PHONE (DISPLAY TYPE changed to Inline Text)
//     HOME PHONE (DISPLAY TYPE changed to Disabled)
//     FAX (checked MANDATORY)
//

recEmployee.setFieldValue('officephone', '111-111-1111');
recEmployee.setFieldValue('mobilephone', '222-222-2222');
recEmployee.setFieldValue('homephone', '333-333-3333');
recEmployee.setFieldValue('fax', '444-444-4444');

// Result during submittal:
//     Script not impacted by hidden fields. Value can still be set to OFFICE PHONE.
//       The value will be there if you redisplay employee using the standard form.
//     Script not impacted by Inline Text fields. Value can still be set to MOBILE PHONE.
//     Script not impacted by Disabled fields. Value can still be set to HOME PHONE.
//     Script is impacted by MANDATORY fields. If FAX does not have a value, and then
//       attempt an update without setting FAX, an error is returned, e.g.
//       "Please enter value(s) for: Fax
//
var employeeId = nlapiSubmitRecord(recEmployee);

var x=0;
