/**
 * Developer Certification
 * 
 * Objective:
 *     Given a scenario, identify the proper pattern to invoke a scheduled script to support
 *     a long running process
 * 
 * This is a scheduled script, showing how it can further process a record from a User Event or
 * Suitelet script.
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type) {
	
	// Grab script parameter values passed from the User Event / Suitelet script that is calling this
	// scheduled script. The script parameters are defined on the Parameters subtab of the scheduled
	// script
	var context = nlapiGetContext();
	var recType = context.getSetting('SCRIPT', 'custscript_sdr_record_type');
	var recId = context.getSetting('SCRIPT', 'custscript_sdr_record_id');

	// now do some work based on the record type and record id passed into this script	    	
	nlapiLogExecution('DEBUG', 'record type', recType);
	nlapiLogExecution('DEBUG', 'internal id', recId);            
}
