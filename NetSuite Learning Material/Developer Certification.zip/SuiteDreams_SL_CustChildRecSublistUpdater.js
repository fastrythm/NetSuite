/**
 * Developer Certification
 * 
 * Objective:
 *     Determine how to interact with custom child record sublists in SuiteScript
 * 
 * This script shows how multiple custom records can be generated via a parent-child record
 * relationship. In this scenario there is a parent custom record type used to hold the
 * relationship. The child is a performance review custom record type. The idea is to generate
 * multiple performance reviews quickly by adding them as sublist lines to a parent record.
 * 
 * A chief reason for creating the performance reviews in this way is that governance usage is
 * limited to the governance of a single nlapiSubmitRecord. There is no usage adding sublist lines.
 * So this is a perfect type of script to use when mass updating/creating a set of custom records.
 */
/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){
	
	if (request.getMethod() == 'GET'){

		var form = nlapiCreateForm('Generate Performance Reviews', false);

		// get parameter that would have been set upon previous POST
		var processed = request.getParameter('custparam_processed');			

		if (processed){
			form.addField('custpage_sdr_message', 'help','5 performance reviews created!!!');			
		} else {
			form.addSubmitButton('Create Performance Reviews');			
		}
		
		response.writePage(form);		
				
	} else {
		
		var context = nlapiGetContext();
		nlapiLogExecution('DEBUG', 'starting usage remaining', context.getRemainingUsage());
		
		var recParent =
		nlapiCreateRecord('customrecord_perf_rev_mass_updater');
		
		var perfReviewList = 'recmachcustrecord_sdr_perf_review_mass_updater';
		var reviewNumber = 1;
		var salary = 3000;
		
		for (var i=0; i < 5; i++){
			recParent.selectNewLineItem(perfReviewList);
			recParent.setCurrentLineItemValue(perfReviewList, 'name', 'review ' + reviewNumber);
			recParent.setCurrentLineItemValue(perfReviewList, 'custrecord_sdr_perf_subordinate', '640');// 640=James Rollings
			recParent.setCurrentLineItemValue(perfReviewList, 'custrecord_sdr_perf_review_date', nlapiDateToString(new Date()));
			recParent.setCurrentLineItemText(perfReviewList, 'custrecord_sdr_perf_review_type', 'Salary Change');
			recParent.setCurrentLineItemValue(perfReviewList, 'custrecord_sdr_perf_rating_code', 'Z');
			recParent.setCurrentLineItemValue(perfReviewList, 'custrecord_sdr_perf_sal_incr_amt', salary);

			recParent.commitLineItem(perfReviewList);		
			
			reviewNumber++;
			salary = salary + 100;
		}
		
		nlapiSubmitRecord(recParent);

		nlapiLogExecution('DEBUG', 'ending usage remaining', context.getRemainingUsage());		

		// Redirect to self
		// Set a parameter indicating that performance reviews were generated, so message can
		// be set upon re-display of the Suitelet	
		var context = nlapiGetContext();
		response.sendRedirect('SUITELET', context.getScriptId(),
				              context.getDeploymentId(), null,
				              {custparam_processed: 'T'});		
	}		
}
