/**
 * Developer Certification
 * 
 * Objective:
 *     Identify strategies for and implications of role management and authentication when integrating with external systems
 * 
 * This Suitelet script focuses on a method of outbound integration. When SuiteSignOn cannot be used, you can securely
 * send credentials out of NetSuite. Requirements:
 * - add credential fields to your form using nlobjForm.addCredentialField()
 * - pass the credentials in an https request using nlapiRequestURLWithCredentials
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){
		
	var context = nlapiGetContext();
	
	if (request.getMethod() == 'GET'){
		var form = nlapiCreateForm('Work with Credential Fields', false);
				
		// The first 5 parameters need to be entered, even though documentation says parameters 3, 4, and 5 are optional. You can
		// however enter the optional parameters as null.
		var fldUserid = form.addCredentialField('custpage_sdr_user_id', 'External System User Id', 'www.somesite.com', context.getScriptId(), null);
		var fldPassword = form.addCredentialField('custpage_sdr_password', 'External System Password', 'www.somesite.com', context.getScriptId(), null);
				
		form.addSubmitButton('Call External System');
		
		response.writePage(form);
		
	} else {
		// POST processing
		
		var userIdHandle = request.getParameter('custpage_sdr_user_id');
		var passwordHandle = request.getParameter('custpage_sdr_password');

		// Check the log and you'll see how the values have been automatically converted into GUIDs (globally unique identifiers),
		// which are used as handles to the actual credential values that were entered on the form.
		nlapiLogExecution('DEBUG', 'handle for user id', userIdHandle);
		nlapiLogExecution('DEBUG', 'handle for password', passwordHandle);
		
		// Check Help Center on how to fully use nlapiRequestURLWithCredentials.
		// nlapiRequestURLWithCredentials makes an https request. The credentials can be listed as an array construct in the
		// first parameter. An exception is returned if you try to use an http url.
		// When you call nlapiRequestURLWithCredentials, the system gets the credential values using the GUID based handles,
		// then encrypts with ssl encryption.
		// 
		//nlapiRequestURLWithCredentials([userIdHandle, passwordHandle], 'https://www.somesite.com');
		
		
		// redirect to self
		response.sendRedirect('SUITELET', context.getScriptId(),
				              context.getDeploymentId());
	}
}
