/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the impact of execution context on user event scripts
 * 
 * This shows how user event scripts are not limited to execution from the user interface.
 * Best practice is to filter script execution based upon execution context so the script
 * is executed only when necessary.
 * 
 * Update a vendor from the Suitelet and see the logging of execution context and fax number.
 * Update a vendor from the UI or other context (e.g. Portlet, SuiteTalk, CSV Import) and
 * only see the logging of execution context.
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord vendor
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function userEventBeforeLoad(type, form, request){
	
	var executionContext = logExecutionContext('beforeLoad');
	
	if (executionContext == 'suitelet') {
		var rec = nlapiGetNewRecord();
		nlapiLogExecution('DEBUG', 'curent fax number loaded by suitelet', rec.getFieldValue('fax'));
	}
	
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord vendor
 * 
 * @param {String} type Operation types: create, edit, delete, xedit
 *                      approve, reject, cancel (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF)
 *                      markcomplete (Call, Task)
 *                      reassign (Case)
 *                      editforecast (Opp, Estimate)
 * @returns {Void}
 */
function userEventBeforeSubmit(type){
	
	var executionContext = logExecutionContext('beforeSubmit');
	
	if (executionContext == 'suitelet') {
		var rec = nlapiGetNewRecord();
		nlapiLogExecution('DEBUG', 'fax number about to be updated by suitelet', rec.getFieldValue('fax'));
	} 
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord vendor
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type){
	
	var executionContext = logExecutionContext('afterSubmit');
	
	if (executionContext == 'suitelet') {
		var rec = nlapiGetNewRecord();
		nlapiLogExecution('DEBUG', 'fax number updated by suitelet', rec.getFieldValue('fax'));
	}
}

function logExecutionContext(event) {
	var context = nlapiGetContext();
	var executionContext = context.getExecutionContext();
	
	nlapiLogExecution('DEBUG', 'execution context at ' + event, executionContext);	
	
	return executionContext;
}
