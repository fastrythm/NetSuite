/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the risks of implementing only client-side validations and
 *     strategies to address them.
 * 
 * This is a User Event script that is performing a validation at Before Submit.
 * Place the validation on the client-side for maximum flexibility, but repeat
 * on the server for safety in case the script does not execute in the browser.

 * In addition to the safety aspect, records may be updated from other contexts
 * than the user interface (e.g. csv import, web services). If you place the
 * validation in the user event script, then the validation will be in place
 * from anywhere the record is updated. Client-side scripts are not executed when
 * records are updated from outside the user interface.
 */


/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord opportunity
 * 
 * @param {String} type Operation types: create, edit, delete, xedit
 *                      approve, reject, cancel (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF)
 *                      markcomplete (Call, Task)
 *                      reassign (Case)
 *                      editforecast (Opp, Estimate)
 * @returns {Void}
 */
function userEventBeforeSubmit(type){
	var recOpportunity = nlapiGetNewRecord();
	
	var projectedTotal = 
		parseFloat(recOpportunity.getFieldValue('projectedtotal'));
		
	if (projectedTotal > 500){
		
		// Throws an exception that cancels submittal of record to the database
		throw nlapiCreateError('INVTOTAL', 'total is greater than the allowable limit', true);
	}
}


