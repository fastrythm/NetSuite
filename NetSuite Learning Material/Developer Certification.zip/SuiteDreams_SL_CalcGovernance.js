/**
 * Developer Certification
 * 
 * Objective:
 *     Calculate the governance of a script
 * 
 * This is a Suitelet script which updates a few records. Remaining usage is logged to help identify
 * api usage. In this example of unit consumption, you'll be able to contrast differences between
 * standard transactional records (e.g. opportunity), standard non-transactional records (e.g. vendor)
 * and custom records (e.g. performance review). 
 * 
 * Note that object methods do not consume usage units. Only certain api functions, such as
 * nlapiLoadRecord and nlapiSubmitRecord.
 * 
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){

	context = nlapiGetContext();
	
	nlapiLogExecution('DEBUG', 'remaining usage - start of GET', context.getRemainingUsage());

	// get parameters for record IDs that would have been set upon previous POST
	var recIdOpportunity = request.getParameter('custparam_opportunityId');		
	var recIdVendor = request.getParameter('custparam_vendorId');		
	var recIdPerfReview = request.getParameter('custparam_perfReviewId');		
	
	if (request.getMethod() == 'GET'){
		var form = nlapiCreateForm('Update Records', false);
	
		var fldOpportunity = form.addField('custpage_sdr_opportunity', 'select', 'Opportunity', 'opportunity');
		(recIdOpportunity) ? fldOpportunity.setDefaultValue(recIdOpportunity) : 0;

		var fldVendor = form.addField('custpage_sdr_vendor', 'select', 'Vendor', 'vendor');
		(recIdVendor) ? fldVendor.setDefaultValue(recIdVendor) : 0;
		
		var fldPerfReview = 
			form.addField('custpage_sdr_perf_review', 'select', 'Performance Review', 'customrecord_sdr_perf_review');
		(recIdPerfReview) ? fldPerfReview.setDefaultValue(recIdPerfReview) : 0;	
		
		form.addSubmitButton('Load and Submit Records');
		
		response.writePage(form);
		
	} else {
		// POST processing
		
		// Load and submit each record, calculating governance along the way
			
		nlapiLogExecution('DEBUG', 'remaining usage - start of POST', context.getRemainingUsage());
		
		var timestamp = nlapiDateToString(new Date(), 'datetimetz');
		
		var recIdOpportunity = request.getParameter('custpage_sdr_opportunity');		
		var recIdVendor = request.getParameter('custpage_sdr_vendor');		
		var recIdPerfReview = request.getParameter('custpage_sdr_perf_review');		
	
		var recOpportunity = nlapiLoadRecord('opportunity', recIdOpportunity);
		nlapiLogExecution('DEBUG', 'remaining usage - after load of Opportunity', context.getRemainingUsage());		
		recOpportunity.setFieldValue('memo', timestamp);
		
		var recVendor = nlapiLoadRecord('vendor', recIdVendor);
		nlapiLogExecution('DEBUG', 'remaining usage - after load of Vendor', context.getRemainingUsage());
		recVendor.setFieldValue('comments', timestamp);

		var recPerfReview = nlapiLoadRecord('customrecord_sdr_perf_review', recIdPerfReview);
		nlapiLogExecution('DEBUG', 'remaining usage - after load of Perf Review', context.getRemainingUsage());
		recPerfReview.setFieldValue('custrecord_sdr_perf_supervisor_comments', timestamp);
		
		nlapiSubmitRecord(recOpportunity);
		nlapiLogExecution('DEBUG', 'remaining usage - after submit of Opportunity', context.getRemainingUsage());		

		nlapiSubmitRecord(recVendor);
		nlapiLogExecution('DEBUG', 'remaining usage - after submit of Vendor', context.getRemainingUsage());		
		
		nlapiSubmitRecord(recPerfReview);
		nlapiLogExecution('DEBUG', 'remaining usage - after submit of Perf Review', context.getRemainingUsage());		
		
		// redirect to self
		// send the selected opportunity, vendor, and performance review record IDs in the
		// request so the dropdowns can be re-populated with their values
		response.sendRedirect('SUITELET', context.getScriptId(),
				              context.getDeploymentId(), null,
				              {custparam_opportunityId: recIdOpportunity,
			                   custparam_vendorId: recIdVendor,
			                   custparam_perfReviewId: recIdPerfReview
				              });
	}
}
