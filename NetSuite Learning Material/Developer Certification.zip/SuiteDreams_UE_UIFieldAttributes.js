/**
 * Developer Certification
 * 
 * Objective:
 *     Determine how to dynamically customize UI field attributes in SuiteScripts
 * 
 * Note: toggling display characteristics of fields (hide/show) while user is editing the form
 *       is best suited for SuiteFlow. You can only make a field disabled in client SuiteScript.
 *       However in SuiteFlow you can toggle other display characteristics in client triggers.
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord salesorder
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function userEventBeforeLoad(type, form, request){

	var rec = nlapiGetNewRecord();
	
	// make STATUS field read-only after creation;
	// normally it is editable for new and existing records
	if (type != 'create'){
		var fldStatus = form.getField('orderstatus');		
		fldStatus.setDisplayType('inline');
	}
	
	// change ORDER # label to ORDER NUMBER, but only when printing
	if (type == 'print'){
		var fldOrderNbr = form.getField('tranid');		
		fldOrderNbr.setLabel('Order Number');		
	}
	
	// on new records, default END DATE to today + 7 days
	if (type == 'create'){
		var today = new Date();
		var endDate = nlapiAddDays(today, 7);
		var endDateText = nlapiDateToString(endDate);
		var fldEndDate = form.getField('enddate');	
		fldEndDate.setDefaultValue(endDateText);
	}
	
	// make MEMO mandatory
	var fldMemo = form.getField('memo');
	fldMemo.setMandatory(true);
	
	// make the DESCRIPTION field in Items sublist mandatory. This captures
	// the case where item does not contain a description or end user
	// inadvertently clears out the text
	// Note: line number param is required, but method will run on all lines
	var fldDescription = rec.getLineItemField('item', 'description', 1);
	fldDescription.setMandatory(true);	
}
