/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the time zone implications of various ways of setting date and/or
 *     time values and the ways in which these values are interpreted in SuiteScript
 * 
 * Tips for Scheduled Scripts and Time Zone
 * ---------------------------------------------------------------------------------
 * - Scheduled scripts execute according to the time zone of the script owner. E.g.
 *   a script set to execute on Dec 31 2015 @ 8:00am will execute at that time, but
 *   according to the TIME ZONE at Home > Set Preferences for the script OWNER
 * - "new Date()" on server returns JavaScript date with time according to Pacific
 *   time zone. This is the same whether the account is located in the west coast or 
 *   east coast data center. As of the time of this writing, your training accounts are
 *   in a data center on the east coast of the United States.
 * - When time zone is not explicitly entered, datetime values are returned using
 *   the TIME ZONE company preference at Setup > Company > Company Information.
 * - TIME ZONE user preference is ignored when selected via nlapiLoadConfiguration.
 *   Instead, the company preference is returned.
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type) {

	// Use a custom record type with a datetime field as a general purpose utility for converting
	// from server timezone to user or company specified timezone. The custom record type should
	// have at least a single date time field. No data records are needed.  
	var recDateTimeConverter = nlapiCreateRecord('customrecord_sdr_datetime_converter');
	
	// Field "custrecord_sdr_user_datetime" uses Current Date/Time as a DYNAMIC DEFAULT 
	// (see Validation & Defaulting subtab of field definition). 
	// DYNAMIC DEFAULT is set to time based on user preference in most scripts
	// DYNAMIC DEFAULT is set to time based on company preference in scheduled scripts
	var userDateTime = recDateTimeConverter.getFieldValue('custrecord_sdr_user_datetime');
	nlapiLogExecution('DEBUG', 'user datetime from datetime field using dynamic default', userDateTime);

	var serverDate = new Date();
	var serverDateTime = nlapiDateToString(serverDate, 'datetimetz');
	nlapiLogExecution('DEBUG', 'current JS date on server - always Pacific time', serverDateTime);		
	
	// We specify the timezone as America/Los_Angeles Olson value. A new JS Date (i.e. using new Date())
	// is always returned in Pacific time, so let's have it associated with this timezone.
	recDateTimeConverter.setDateTimeValue('custrecord_sdr_server_datetime', serverDateTime,
			                              'America/Los_Angeles');
	
	// Returns in timezone of user preference in most scripts
	// Returns in timezone of company preference in scheduled scripts
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with no timezone specified', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime'));

	// getFieldValue returns the same as getDateTimeValue when 2nd parameter not entered
	nlapiLogExecution('DEBUG', 'getFieldValue - returned with no timezone specified', 
			recDateTimeConverter.getFieldValue('custrecord_sdr_server_datetime'));

	// Converts the time (currently stored as Pacific) to Mountain
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with explicit conversion to America/Denver time', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime','America/Denver'));
	
	// Return the TIME ZONE user preference setting in most scripts
	// Returns the TIME ZONE company preference setting in scheduled scripts 
	// The time zone value is returned as an Olson value, e.g. "Asia/Manila"
	var userTimeZone = nlapiLoadConfiguration('userpreferences').getFieldValue('timezone');
	nlapiLogExecution('DEBUG', 'user time zone', userTimeZone);	
	
	
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with explcit conversion to user timezone', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime', userTimeZone));	
	
	// Return the the TIME ZONE company preference setting. The time zone value is returned as an
	// Olson value, e.g. "Asia/Manila"
	var companyTimeZone = nlapiLoadConfiguration('companyinformation').getFieldValue('timezone');
	nlapiLogExecution('DEBUG', 'company time zone', companyTimeZone);	
	
	nlapiLogExecution('DEBUG', 'getDateTimeValue - returned with explcit conversion to company timezone', 
			recDateTimeConverter.getDateTimeValue('custrecord_sdr_server_datetime', companyTimeZone));	
}
