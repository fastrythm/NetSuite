/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the performance implications of adding custom fields and the strategies to
 *     mitigate performance impact
 *
 * Custom fields that source data in from other fields, assign default values through
 * formulas, or assign default values through a search can all impact the performance
 * of loading a record. This configuration can be found on the "Validation & Defaulting"
 * and "Sourcing & Filtering" subtabs of custom field definitions.
 * 
 * With scripts you can load a record for update using a custom form that has the custom
 * fields set to hidden, inline text, or disabled. However, doing so does not keep default
 * values from calculating. The fields are still returned in the resultant nlobjRecord,
 * meaning there is still a performance impact.
 * 
 * Some ways to mitigate the performance impact in scripts:
 *     - Remove all access to the field for specified role. If the script is set to run
 *       under the same role, then field is not returned during nlapiLoadRecord. On
 *       custom field definition: go to Access, Role subtab. Mark ACCESS LEVEL as None
 *       for desired Role.
 *     - Execute a search using nlapiSearchRecord, nlapiLookupField, or nlobjSearch.
 *       With searches you can choose only those fields to return. Note that 
 *       under the covers nlapiLookupField is executing a search.
 *     - On custom field definition, uncheck SHOW IN LIST. Checking this causes the
 *       field to be set as a default on the Results subtab of a saved search. This
 *       is especially good as a way to help end users get better performance in the
 *       user interface. They have to explicitly add the custom field to the Results
 *       if they want to return it. 
 */

/*
 * Set up custom field with search result default. This can be used with scripting
 * test below. 
 *
 * Note: transaction saved saved is pre-built in your account and named 
 *       Perf Implications Custom Field Summary Field
 * Note: custom field is pre-built in your account and named 
 *       Perf Implications Custom Field
 *
 *     1 - Create public transaction saved search.
 *         Criteria:
 *             Type is Quote (may be called Estimate)
 *             Main Line is false
 *         Results:
 *             Amount (SUMMARY TYPE = Sum)
 *         Available Filters:
 *             Internal ID
 *     2 - Create custom transaction body field
 *         TYPE: Currency
 *         Applies To subtab: SALE
 *         Display subtab: SUBTAB Main, DISPLAY TYPE Inline Text
 *         Validation & Defaulting subtab: SEARCH - select the search in step #1 above
 */

// Open an existing Quote (or Estimate) record in the user interface. Note the default value
// calculated for the custom field and displayed in the user interface.

// Replicate opening a quote via the script debugger
// You should see the default value for the custom field
var recQuote = nlapiLoadRecord('estimate', 497);
var custFieldValue = recQuote.getFieldValue('custbody_sdr_perf_impl_cust_field');
nlapiLogExecution('DEBUG', 'custom field value', custFieldValue);

// Edit the custom field definition. Go to the Access subtab and configure the
// Administrator role on the Role sublist. Set ACCESS LEVEL and 
// LEVEL FOR SEARCH/REPORTING to None.
// Re-execute the above script and note the custom field value is not returned.
// In cases where you don't need this value, this should increase performance.
// This technique has potential in Suitelet, User Event, and Portlet scripts
// where you can change the role used during script execution by configuring the
// EXECUTE AS ROLE dropdown.
