/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the impact of execution context on user event scripts
 * 
 * This is a simple Suitelet that loads and updates a vendor record.
 * Check what happens with any user event scripts that might be deployed to vendors. 
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){

	context = nlapiGetContext();
	var vendorId = '201';  // hardcoding a vendor internal id to use for testing this script
		
	if (request.getMethod() == 'GET'){
		var form = nlapiCreateForm('Update Records', false);
	
		var recVendor = nlapiLoadRecord('vendor', vendorId); 
		var vendorName = recVendor.getFieldValue('entityid');
		var vendorFax = recVendor.getFieldValue('fax');

		
		var fldVendorName = form.addField('custpage_sdr_vendor_name', 'text', 'Vendor Name');
		fldVendorName.setDefaultValue(vendorName);
		fldVendorName.setDisplayType('inline');
		
		var fldVendorFax = form.addField('custpage_sdr_vendor_fax', 'phone', 'Vendor Fax');
		fldVendorFax.setDefaultValue(vendorFax);
		fldVendorFax.setDisplayType('normal');
				
		form.addSubmitButton('Update Vendor');
		
		response.writePage(form);
		
	} else {
		// POST processing
		
		// Update vendor record		
		var vendorFax = request.getParameter('custpage_sdr_vendor_fax');		
	
		var recVendor = nlapiLoadRecord('vendor', vendorId);
		recVendor.setFieldValue('fax', vendorFax);	
		nlapiSubmitRecord(recVendor);
		
		// redirect to self
		response.sendRedirect('SUITELET', context.getScriptId(),
				              context.getDeploymentId());
	}
}
