/**
 * Developer Certification
 * 
 * Objective:
 *     Given a scenario, identify the proper pattern to invoke a scheduled script to support
 *     a long running process
 * 
 * This is a Suitelet script that is off-loading processing asynchronously to a scheduled script.
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){

	if (request.getMethod() == 'GET'){
		var form = nlapiCreateForm('Post Opportunity', false);
		form.addField('custpage_sdr_opportunity', 'select', 'Opportunity', 'opportunity');

		form.addSubmitButton('Post Opportunity');
		
		response.writePage(form);
		
	} else {
		// POST processing
		
		// do some work
		var recId = request.getParameter('custpage_sdr_opportunity');		
		
		nlapiLogExecution('DEBUG', 'internal id', recId);
		
		// We want to do some more work, but it is a lot of effort and could both impact
		// user response time, and perhaps exceed governance limits of Suitelet scripts.
		// Recall that all processing in the POST of a Suitelet script is synchronous. 
		// We can move some of the heavy lifting to a scheduled script. We can pass the context
		// of the current record as script parameters when calling the scheduled script.
		var status =
		nlapiScheduleScript('customscript_sdr_sc_invoked_other_script', 
				            'customdeploy_sdr_sc_invoked_other_script',
				            {custscript_sdr_record_type: 'opportunity',
			                 custscript_sdr_record_id: recId});
		
		nlapiLogExecution('DEBUG', 'status of invoking scheduled script', status);
		
		// Redirect back to self (GET method)
		var context = nlapiGetContext();
		
		response.sendRedirect('SUITELET', context.getScriptId(),
				              context.getDeploymentId());
	}
}
