/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the risks of implementing only client-side validations and
 *     strategies to address them.
 * 
 * Risks with client-side validation:
 *     1 - There is a general risk of script behaving incorrectly in the browser. You can get around
 *         this by repeating validation at Before Submit in User Event script.
 *     2 - There is a risk of the algorithm used in the validation being exposed to the end user. 
 *         The algorithm can be easily seen by inspecting the html page source of the web page.
 *         See clientSaveRecord_option2 that keeps validation on the client in support of a 
 *         better user experience, but uses a Suitelet to contain the validation algorithm.
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord opportunity
 *   
 * @returns {Boolean} True to continue save, false to abort save
 * 
 * In this option, the entire validation is on the client.
 * 
 */
function clientSaveRecord_option1(){

	var projectedTotal = parseFloat(nlapiGetFieldValue('projectedtotal'));
	
	if (projectedTotal > 1000){
		alert('total is greater than the allowable limit');
		return false;
	}
	
    return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord opportunity
 *   
 * @returns {Boolean} True to continue save, false to abort save
 * 
 * In this option, the validation is executed from the client, but the validation algorithm is
 * hidden in a Suitelet on the server.
 * 
 */
function clientSaveRecord_option2(){
	
	var projectedTotal = nlapiGetFieldValue('projectedtotal');
	
	var url = nlapiResolveURL('SUITELET',
			                  'customscript_sdr_sl_client_validations',
			                  'customdeploy_sdr_sl_client_validations');
	
	// call Suitelet; this makes a POST request (AJAX)
	var response = nlapiRequestURL(url, projectedTotal);
	
	if (response.getBody() == 'F'){
		alert('total is greater than the allowable limit');
		return false;
	}
	
    return true;
}
