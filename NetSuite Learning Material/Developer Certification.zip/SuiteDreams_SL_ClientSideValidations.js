/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the risks of implementing only client-side validations and
 *     strategies to address them.
 * 
 * This is a Suitelet script which performs some data validation.
 * This script is called as an AJAX request from a client-side SuiteScript.
 * The advantage of validating in the Suitelet is the validation algorithm is
 * hidden from the front-end. And because this Suitelet is called as an AJAX
 * request, the user experience is not impacted.
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){

	if (request.getMethod() == 'POST'){

		var projectedTotal = parseFloat(request.getBody());
		
		if (projectedTotal > 1000){
			response.write('F');
		} else {
			response.write('T');
		}
	}
}
