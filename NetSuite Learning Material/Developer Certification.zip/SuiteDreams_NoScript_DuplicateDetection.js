/**
 * Developer Certification
 * 
 * Objective:
 *     Identify how to detect and prevent duplicate records.
 * 
 * Enable duplicate detection at Setup > Company > Enable Features, Company subtab, Data Management section
 * 
 * There is both a user interface and scripted capability for duplicate detection. The scripted capability
 * has the same capability as the user interface, but serves two additional purposes:
 * 1 - automate the actions to take on duplicate records (e.g. merge duplicate records, delete duplicate records)
 * 2 - apply custom rules in determining which records are duplicates
 *  
 * Rules for duplicate detection in the user interface are configured at Setup > Company > Duplicate Detection.
 * You can identify matching fields that indicate duplicates. Records supported are customers, vendors, partners,
 * and contacts. Customers include leads and prospects.
 *     
 * In the user interface you can take action to merge or delete duplicates at 
 * Lists > Mass Update > Entity Duplicate Resolution. The actions you can take are similar to what you can
 * configure through script. You can also take action on potential duplicates while editing/creating a record,
 * as the potential for duplicates is automatically flagged based on the duplicate detection rules.
 * 
 * The status of duplicate detection actions taken in both the user interface and in script can be seen
 * at Lists > Mass Update > Duplicate Resolution Status.
 */


// Detect duplicate vendor records, where fax = specific value. This is your custom rule. 
// In this simple example a set of vendor records are returned from a search, based on the value of the fax number. 
// The internal IDs of the vendor records in the result set are marked as duplicate. A merge operation is
// executed, and the master record (the one that is kept) is the earliest created.
var columns = new Array();
columns[columns.length] = new nlobjSearchColumn('datecreated');
columns[columns.length] = new nlobjSearchColumn('phone');

var filterExpression = ['fax','is','555-555-5555'];

var search = nlapiCreateSearch('vendor', filterExpression, columns);
var searchResultSet = search.runSearch();
var searchResults = searchResultSet.getResults(0, 999);

// set duplicate records
var duplicateRecords = [];
for (var i = 0; i < searchResults.length; i++)
{
	duplicateRecords[i] = searchResults[i].getId();
}

// Get a job manager instance, which is a wrapper for a duplicate job request 
// Returns nlobjJobManager
var jobManager = nlapiGetJobManager('DUPLICATERECORDS');  

// Return a job request, specifically an nlobjDuplicateJobRequest
var jobRequest = jobManager.createJobRequest();

// Set duplicate records based on above search
jobRequest.setRecords(duplicateRecords);

// Set the entity type to indicate they are vendor records
jobRequest.setEntityType(jobRequest.ENTITY_VENDOR);

// Set the master based on earliest created record
jobRequest.setMasterSelectionMode(jobRequest.MASTERSELECTIONMODE_CREATED_EARLIEST);

// Set the merge operation type 
jobRequest.setOperation(jobRequest.OPERATION_MERGE);

// Submit a job to process asynchronously. Submitting the job does not execute the job.
// Submitting the job places the job in the queue.
jobId = jobManager.submit(jobRequest);

// Check the job status, returns nlobjFuture
// You can see status in the user interface at Lists > Mass Update > Duplicate Resolution Status
var future = jobManager.getFuture(jobId);

var x=0;
