/**
 * Developer Certification
 * 
 * Objective:
 *     Given a scenario, identify the proper pattern to invoke a scheduled script to support
 *     a long running process
 * 
 * This is a User Event script that is off-loading processing asynchronously to a scheduled script.
 */


/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord opportunity
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type){

	// do some work
	var recOpportunity = nlapiGetNewRecord();
	var recType = recOpportunity.getRecordType();
	var recId = recOpportunity.getId();
	
	nlapiLogExecution('DEBUG', 'record type', recType);
	nlapiLogExecution('DEBUG', 'internal id', recId);
	
	// We want to do some more work, but it is a lot of effort and could both impact
	// user response time, and perhaps exceed governance limits of UE scripts.
	// Recall that all processing in a UE script is synchronous. We can move some of
	// the heavy lifting to a scheduled script. We can pass the context of the current
	// record as script parameters when calling the scheduled script.
	var status =
	nlapiScheduleScript('customscript_sdr_sc_invoked_other_script', 
			            'customdeploy_sdr_sc_invoked_other_script',
			            {custscript_sdr_record_type: recType,
		                 custscript_sdr_record_id: recId});
	

	nlapiLogExecution('DEBUG', 'status of invoking scheduled script', status);
}
