/**
 * Developer Certification
 * 
 * Objective:
 *     Determine which variables would be good candidates to use as a company
 *     preference, user preference, or Script Deployment parameter.
 * 
 * Note: this script is deployed to sales orders and estimates
 * 
 * Scenario:
 *     A PDF transaction print of a sales order or estimate may be emailed to the related Sales Rep
 *     automatically at the time of transaction creation based on a custom preference setting. 
 *     Each Sales Rep should be able to set this individually.
 *     
 *     The subject line of the email is configurable by the script creator and may be different
 *     across sales orders and estimates. The script should not be modified in order to change
 *     the subject line.
 *     
 * Based on the above scenario, a User Preference allows Sales Reps to set their printing preference.
 * 
 * And since subject line is different per each transaction type, setting should be created as
 * Script Deployment parameter. Company Preference would have been applicable if subject line were
 * the same across transaction types.
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord salesorder
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type){
	
	var context = nlapiGetContext();
	
	var sendCopyOrderEstimate = context.getSetting('SCRIPT', 'custscript_sdr_copy_orderest'); 
	
	if (type == 'create' && sendCopyOrderEstimate == 'T'){
		var rec = nlapiGetNewRecord();
		
		// sales rep may be optional
		if (rec.getFieldValue('salesrep')){
			var file = nlapiPrintRecord('TRANSACTION', rec.getId(), 'PDF');
			
			var subject = context.getSetting('SCRIPT','custscript_sdr_subject');
			var recordsToAttach = [{transaction: rec.getId()}];
			
			nlapiSendEmail(context.getUser(), rec.getFieldValue('salesrep'), subject,
					       'see attachment', null, null, recordsToAttach, file);	
		}			
	}
}
