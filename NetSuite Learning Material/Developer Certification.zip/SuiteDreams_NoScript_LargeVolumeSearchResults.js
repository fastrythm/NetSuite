/**
 * Developer Certification
 * 
 * Objective:
 *     Identify implications of managing a large volume of search results
 * 
 * This search script follows a pattern of how one can return search results 
 * over 1000 records using nlapiSearchRecord. Each execution of nlapiSearchRecord 
 * returns a maximum of 1000 records.
 * 
 * This can be tested in the script debugger.
 * 
 * Return all payment transactions. The idea is to return more than
 * 1000 records so the 1000 record limit and workaround can be tested.
 * 
 * Return the tranid (transaction number), amount, and internalid
 * of the transaction. Internalid is used to return subsequent
 * transactions beyond 10,000.
 * 
 * This search constructs columns and filters manually. A saved search
 * is not executed. Each execution of nlapiSearchRecord returns the
 * next 1000 records or the last set of records if less than 1000.
 * 
 * Note: If you are performing additional database operations upon each search
 *       result such as executing nlapiLoadRecord/nlapiSubmitRecord, then you
 *       also need to take governance into account. You can embed this pattern
 *       into scheduled scripts, including those that are requeued. The internal id
 *       of the last record processed can be passed in a script parameter via
 *       nlapiScheduleScript. See the following objective for more information:
 *       "Given a scenario, identify the proper pattern to invoke a scheduled script 
 *        to support a long running process"
 */

// Set up columns to return in result set. tranid and amount columns are
// extraneous to the pattern being shown. 
//
// Results are sorted by internalid, allowing another execution of nlapiSearchRecord
// to return the next set of records whose internalid is greater than the last one 
// returned in the prior result set.
var columns = [];
columns[0] = new nlobjSearchColumn('tranid'); // transaction number
columns[1] = new nlobjSearchColumn('amount');
columns[2] = new nlobjSearchColumn('internalid').setSort();

// Set up filters to restrict the result set. These filters are extraneous to the 
// pattern being shown. The filter is to return Customer Payment transactions.
// In the user interface navigate to:
//     Transactions > Customers > Accept Customer Payments > List
// You'll see more than 10,000 records. This gives us a very good test.
var filters = [];
filters[0] = new nlobjSearchFilter('type', null, 'anyof', 'CustPymt');
filters[1] = new nlobjSearchFilter('mainline', null, 'is', 'T');

var recsProcessed = 0; // total number of search results

// grab first set of search results					  		  
var searchResults = nlapiSearchRecord('transaction', null, filters, columns);

// If there are less than 1000 search results, then get out of loop and log the
// records processed.
//
// If there are 1000 search results, then re-execute the search, getting the next
// set of records based on the internalid of the last record in the current set of results 
while (searchResults.length == 1000){
	
	// keep a running total of the number of records processed and log it
	recsProcessed = recsProcessed + searchResults.length;
	nlapiLogExecution('DEBUG', 'records processed: ' + recsProcessed);

	// Get the internal id of the last record in the current result set
	// The 999 index is the 1000th array entry.
	var lastInternalId = searchResults[999].getValue('internalid');
	
	// Add a 3rd filter, restricting the result set based on the last
	// internal id
	filters[2] = new nlobjSearchFilter('internalidnumber',null,
	                                   'greaterthan',lastInternalId)
									   
	// get another set of search results
	searchResults = nlapiSearchRecord('transaction', null, filters, columns);		
}

// log the last set of search results
recsProcessed = recsProcessed + searchResults.length;
nlapiLogExecution('DEBUG', 'records processed: ' + recsProcessed);

// dummy statement for use with script debugger
var x=0;

