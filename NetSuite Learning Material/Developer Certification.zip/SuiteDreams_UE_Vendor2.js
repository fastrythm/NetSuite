/**
 * Developer Certification
 * 
 * Objective:
 *     Identify the implications of deploying multiple User Event scripts against a
 *     single record, order of execution, and how user events interact with other
 *     records in SuiteCloud technologies.
 * 
 * This and the other two SuiteDreams_UE_Vendor scripts are each deployed to the Vendor record.
 * The content of each script is minimal. A timestamp (number of milliseconds) is taken at the
 * start of each event function and placed into the execution log.
 * 
 * Through analysis of the timestamps, you'll be able to identify how multiple user event scripts
 * deployed to a single record execute. Order of execution can be controlled at 
 * Customization > Scripting > Scripted Records.
 * 
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord vendor
 * 
 * @param {String} type Operation types: create, edit, delete, xedit
 *                      approve, reject, cancel (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF)
 *                      markcomplete (Call, Task)
 *                      reassign (Case)
 *                      editforecast (Opp, Estimate)
 * @returns {Void}
 */
function userEventBeforeSubmit(type){
	
	var ms = new Date().getTime();
	nlapiLogExecution('DEBUG', 'Before Submit Milliseconds', ms);
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord vendor
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type){
	
	var ms = new Date().getTime();
	nlapiLogExecution('DEBUG', 'After Submit Milliseconds', ms);}
