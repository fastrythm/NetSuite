/**
 * Developer Certification
 * 
 * Objective:
 *     Recognize the purpose of Plug-Ins in SuiteScript
 * 
 * This is an alternate implementation for a plug-in.
 * It provides a different way of generating random numbers.
 * It provides a different way of calculating number precision
 * 
 */

/*
 * Default:
 *     Generate random number, establishing a maximum. One is added, so number will 
 *     never be less than one. Math.random generates random number between 0 and 1.
 * 
 * Alternate: 
 *     Instead of using Math.floor which returns an integer; use 
 *     Number.toFixed to preserve the indicated decimal places.
 */ 
function generateRandomNumber(maxNbr, decimalPlaces)
{	
	var randomNumber = 
		(Math.random() * maxNbr) + 1;
	
	return randomNumber.toFixed(decimalPlaces);
}

/*
 * Default:
 *     Pass in a number and pad to specified length
 * 
 * Alternate:
 *     Pass in a number and pad the decimals (not entire number) to specified digits
 */
function setPrecision(number, length)
{
	return number.toFixed(length);
}
