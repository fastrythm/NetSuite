/**
 * Developer Certification
 * 
 * Objective:
 *     Identify how to dynamically scale a scheduled script utilization to match
 *     available queues in the account
 * 
 * This is a Suitelet that executes a scheduled script to process all the support cases in the
 * account. Support cases are evenly divided into groups based on the number of scheduled
 * script queues in the account. The idea is to split the processing evenly across queues, so
 * that all queues are being utilized.
 * 
 * The algorithm is just one example of how you might have a process utilize the available
 * queues. The algorithm does the following:
 *     - Execute a search to return all the support cases
 *     - Calculate number of cases per queue
 *     - Loop through the support cases, scheduling script deployments
 *       across each queue
 *       
 * The algorithm relies on the fact that each script deployment id has a sequence number at the
 * end to match up with a queue number. If the intent is to utilize all queues, then script should
 * be created with 15 deployments. Note: some customers can have up to 3 SuiteCloud Plus licenses,
 * which provide 15 scheduled script queues.
 * 
 * Limitations of this "simple" algorithm:
 *     - The algorithm utilizes all queues. It is possible that for some scenarios, you may
 *       want to use only a subset of queues to free up other queues for other work
 *     - The algorithm does not handle search result limits. E.g. nlapiSearchRecord only returns
 *       a max of 1000 results. There are ways around this, but is not covered here.
 *     - The scheduled scripts that are executed do not handle governance limits. There are ways
 *       around this (e.g. nlapiScheduleScript to re-queue), but that is not covered here.
 *     - Some records at the end of the result set may not get processed in a scheduled script.
 *       E.g. 103 cases / 5 available queues =  ceil(20.6) = 21 to be processed per queue. Four
 *            queues will process the first 84 cases. The last set of cases will not be processed
 *            because they are less than 21.
 *       There are ways around this, but is not covered here.
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){

	if (request.getMethod() == 'GET'){
				
		var form = nlapiCreateForm('Process Support Cases', false);

		// get parameter that would have been set upon previous POST
		var processed = request.getParameter('custparam_processed');			

		if (processed){
			form.addField('custpage_sdr_message', 'help','Support case deployments scheduled!!!');			
		} else {
			form.addSubmitButton('Process Support Cases');			
		}
		
		response.writePage(form);
		
	} else {
		
		var searchResults = nlapiSearchRecord('supportcase', 'customsearch_sdr_get_support_cases');
		var numberOfCases = searchResults.length;
		var numberOfQueues = nlapiGetContext().getQueueCount(); // number of queues in the account
		
		// Math.ceil will raise to the next whole number. This might cause the last queue to
		// go unused. But this way we don't end up with a fraction of a support case
		var numberOfCasesPerQueue = Math.ceil(numberOfCases / numberOfQueues);
		
		var startId = 0, currentId, currentQueue;
		
		for (var i=1; i <= searchResults.length; i++){
			
			currentId = searchResults[i-1].getId();
			
			if (i % numberOfCasesPerQueue == 0) 
			{ 
				
				// We design the scheduled script deployment IDs to contain sequential numbers
				// so we can easily match up with the current queue. Current queue is
				// i / numberOfCasesPerQueue
				currentQueue = i / numberOfCasesPerQueue;
				
				// Call scheduled script, passing in start id and current id
				// Start id is the starting internal id and current id is the ending.
				// Schedule different deployment each time through (each deployment set
				// to different queue)
				nlapiScheduleScript('customscript_sdr_sc_available_queues', 
						            'customdeploy_sdr_sc_available_queues_' + currentQueue,
						            {custscript_sdr_start_case_id: startId,
	                                 custscript_sdr_end_case_id: currentId});
				
				nlapiLogExecution('DEBUG', 'deployment scheduled!',
						          'customdeploy_sdr_sc_available_queues_' + currentQueue + 
						          ' to process internal IDs between ' + startId + ' and ' +
						          currentId);
				
				// setting the startId for the next set of cases
				startId = parseInt(currentId) + 1;				
			}	
		}
		
		// Redirect to self
		// Set a parameter indicating that deployments were scheduled, so message can
		// be set upon re-display of the Suitelet	
		var context = nlapiGetContext();
		response.sendRedirect('SUITELET', context.getScriptId(),
				              context.getDeploymentId(), null,
				              {custparam_processed: 'T'});
	}				
}
