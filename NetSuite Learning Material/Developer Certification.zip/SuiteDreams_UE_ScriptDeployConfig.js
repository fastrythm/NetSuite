/**
 * Developer Certification
 * 
 * Objective:
 *     Recognize script deployment configuration across script types
 * 
 * First execute this script as is with the Administrator Larry Nelson.
 * Note the following:
 *     - when an expense report is created
 *       - there is one audit logging and two debug loggings
 *       - the related employee record is updated
 *     - when an expense report is being updated
 *       - there is one debug logging
 *       
 * Create an employee (John Smith) with login access and Employee Center role. Log in as
 * this employee and create an expense report. The script does not execute.
 * 
 * See SuiteDreams_UE_ScriptDeployConfigAnswers.txt for answers to the following questions.
 *
 * How can you continue to run the script in testing mode, but have it 
 * execute for John Smith?
 * 
 * Adjust per answer then execute again. The script runs, but
 * you get a permission violation. How do you fix the permission
 * violation, assuming this script must run and update the employee record
 * when expense reports are created?
 * 
 * With OWNER set to John Smith, log back in as Larry Nelson.
 * Make the script available for everyone, including Larry Nelson.
 * 
 * Now create an expense report while logged in as Larry Nelson. Note there
 * is no longer anything written to the execution log. In general when you
 * release a script, you don't want debug loggings. However, there is
 * the audit logging. What do you need to do to allow Audit loggings to 
 * take place with released scripts?
 *     
 * Update an expense report and notice the Audit logging for expense reports
 * is not being created. What can you set on the script deployment to have
 * the script only execute when an expense report is being created?
 */


/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord expensereport
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type){
	
	// filter processing to when new expense reports are created
	if (type == 'create'){
		nlapiLogExecution('AUDIT', 'expense report being created');
		
		var recExpenseRpt = nlapiGetNewRecord();
		var name = recExpenseRpt.getFieldText('entity');
		var total = recExpenseRpt.getFieldValue('total');
		
		nlapiLogExecution('DEBUG', 'exp report name', name);
		nlapiLogExecution('DEBUG', 'exp report total', total);
	
		var recEmployee = nlapiLoadRecord('employee', recExpenseRpt.getFieldValue('entity'));
		recEmployee.setFieldValue('comments', 'total from latest expense report: ' + total);
		nlapiSubmitRecord(recEmployee);
	} else {
		nlapiLogExecution('DEBUG', 'exp report not being created');		
	}
}
