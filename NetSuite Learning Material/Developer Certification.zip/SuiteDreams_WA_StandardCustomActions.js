/**
 * Developer Certification
 * 
 * Objective:
 *     Identify how to configure standard actions and define custom actions
 * 
 * Provides a simple shell for custom action script. It is really generic and
 * could be executed within any workflow.
 */
/**
 * @returns {Void} Any or no return value
 */
function workflowAction() {

	// you can pass in parameters from a workflow
	var param1 = nlapiGetContext().getSetting('SCRIPT','custscript_sdr_wa_param1');
	
	nlapiLogExecution('DEBUG', 'param1', param1);
	
	// record context in workflow gets passed in automatically
	var record = nlapiGetNewRecord();
	var recordType = record.getRecordType();
	var recordId = record.getId();
	
	nlapiLogExecution('DEBUG', 'record type', recordType);
	nlapiLogExecution('DEBUG', 'record id', recordId);
	
	// you can pass a return value from a custom action
	return 'SUCCESS';
}
