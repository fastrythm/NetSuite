/**
 * Developer Certification
 * 
 * Objective:
 *     Identify implications of using saved searches and coded searches
 * 
 * Edit the saved search and uncheck PUBLIC. Change the OWNER to someone other than
 * Larry Nelson. Re-execute and note the search fails. The system assumes the search
 * does not exist. The saved search must be set to PUBLIC to execute through SuiteScript, 
 * unless the user is the same as the OWNER of the saved search.
 * 
 * Edit the saved search and re-check PUBLIC, but remove the Administrator role from the
 * Audience subtab. Re-execute and the search again fails. The system assumes the search
 * does not exist if the user is not granted access through the Audience subtab.
 * Note: the search may continue to execute without error when executed in the debugger.
 * 
 * Note the saved search contains a formula field that formats the amount with a dollar sign.
 * Unlike in SuiteTalk, you will see this field in the search results as it is possible to 
 * return formula fields in SuiteScript. 
 * 
 * Not shown in this example: you can execute summary searches in SuiteScript, which is not 
 * possible in SuiteTalk. These can be saved searches or fully coded searches.
 * 
 * Not shown in this example: You can add dynamic filters and combine with the saved search.
 * See SuiteDreams_SC_AvailableQueues.js for example of combining a saved search with a dynamic
 * filter.
 */

// execute the saved search
var searchResults = nlapiSearchRecord('transaction', 'customsearch_sdr_find_estimates_in_sub');

// get search columns from first search result
// Note: search columns returned in same order as in saved search definition
var columns = searchResults[0].getAllColumns();

// log name and formula field values, including definition of formula
var customerName = searchResults[0].getText(columns[2]);
var formattedAmount = searchResults[0].getValue(columns[4]);
var formattedAmountFormula = columns[4].getFormula();

nlapiLogExecution('DEBUG', 'customer', customerName);
nlapiLogExecution('DEBUG', 'formatted amount', formattedAmount);
nlapiLogExecution('DEBUG', 'formula for formatted amount', formattedAmountFormula);

var x=0;