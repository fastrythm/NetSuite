/**
 * Developer Certification
 * 
 * Objective:
 *     Identify record-locking behavior and options
 * 
 * This script is non-specific to any script type. It can be executed in the script debugger.
 * The script loads and updates standard and custom records in a couple different ways to
 * show the locking behavior exhibited.
 * 
 * Standard records follow optimistic locking behavior.
 * 
 * Custom records follow optimistic locking behavior only when ENABLE OPTIMISTIC LOCKING
 * is checked on the Custom Record Type definition. Otherwise, there is no locking
 * and the potential for data integrity issues exist.
 * 
 * The same locking behavior exists in script and in the user interface.
 * 
 * See http://en.wikipedia.org/wiki/Lock_(database)
 * See http://en.wikipedia.org/wiki/Optimistic_concurrency_control
 */

// Load and then re-load the same employee record.
// Submit first record object - success!
// Submit second record object - "Record has been changed" error
var recEmployee1 = nlapiLoadRecord('employee', 15);
var recEmployee2 = nlapiLoadRecord('employee', 15);

nlapiSubmitRecord(recEmployee1);
nlapiLogExecution('DEBUG', 'recEmployee1 update success!');

nlapiSubmitRecord(recEmployee2); // "Record has been changed" error is thrown by the system
nlapiLogExecution('DEBUG', 'recEmployee2 update success!');

// Load and submit employee record, then re-load the same employee record and submit again.
// Submit first record object - success!
// Submit second record object - success, because this was loaded after the first record object submitted
var recEmployee1 = nlapiLoadRecord('employee', 15);
nlapiSubmitRecord(recEmployee1);
nlapiLogExecution('DEBUG', 'recEmployee1 update success!');

var recEmployee2 = nlapiLoadRecord('employee', 15);
nlapiSubmitRecord(recEmployee2);
nlapiLogExecution('DEBUG', 'recEmployee2 update success!');

// Optimistic locking remains in place when actions are combined between the user interface and script
//   1 - Open the same employee record for editing in the user interface
//   2 - Run the above script in the debugger, but stop after the nlapiLoadRecord statement
//   3 - Save the employee record in the user interface (success!)
//   4 - Continue the script, having it execute nlapiSubmitRecord. "Record has been changed" error returned 


// Open the Performance Review Custom Record Type definition and uncheck ENABLE OPTIMISTIC LOCKING
// Load and then re-load the same performance review record.
// Submit first record object - success!
// Submit second record object - success, because optimistic record locking was not enabled. This
//     may cause integrity issues.
var recPerfReview1 = nlapiLoadRecord('customrecord_sdr_perf_review', 1);
var recPerfReview2 = nlapiLoadRecord('customrecord_sdr_perf_review', 1);

nlapiSubmitRecord(recPerfReview1);
nlapiLogExecution('DEBUG', 'recPerfReview1 update success!');

nlapiSubmitRecord(recPerfReview2);
nlapiLogExecution('DEBUG', 'recPerfReview2 update success!');

// Open the Performance Review Custom Record Type definition and check ENABLE OPTIMISTIC LOCKING
// Run the same script as above. This time the submittal of the 2nd record object returns the
// error "Record has been changed"
